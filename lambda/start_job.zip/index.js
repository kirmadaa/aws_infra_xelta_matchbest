exports.handler = async (event) => { console.log("start_job", event); return { statusCode: 200 }; };
