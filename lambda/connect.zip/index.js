exports.handler = async (event) => { console.log("connect", event); return { statusCode: 200 }; };
