'use strict';

exports.handler = (event, context, callback) => {
    const request = event.Records[0].cf.request;
    const headers = request.headers;

    // Define a mapping of continents/regions to AWS regions
    const regionMapping = {
        'EU': 'eu-central-1',
        'AS': 'ap-south-1',
        'NA': 'us-east-1',
        'SA': 'us-east-1',
        'OC': 'ap-south-1', // Oceania
        'AF': 'eu-central-1', // Africa
    };

    // A mapping of country codes to continents
    const countryToContinent = {
        'DE': 'EU', 'FR': 'EU', 'GB': 'EU', 'IT': 'EU', 'ES': 'EU', 'PL': 'EU', 'RO': 'EU', 'NL': 'EU', 'BE': 'EU', 'GR': 'EU', 'CZ': 'EU', 'PT': 'EU', 'SE': 'EU', 'HU': 'EU', 'AT': 'EU', 'CH': 'EU', 'BG': 'EU', 'DK': 'EU', 'FI': 'EU', 'SK': 'EU', 'IE': 'EU', 'HR': 'EU', 'LT': 'EU', 'SI': 'EU', 'LV': 'EU', 'EE': 'EU', 'CY': 'EU', 'LU': 'EU', 'MT': 'EU', 'IS': 'EU', 'NO': 'EU', 'RS': 'EU', 'BA': 'EU', 'MK': 'EU', 'AL': 'EU',
        'IN': 'AS', 'CN': 'AS', 'JP': 'AS', 'KR': 'AS', 'ID': 'AS', 'PK': 'AS', 'BD': 'AS', 'PH': 'AS', 'VN': 'AS', 'TR': 'AS', 'IR': 'AS', 'TH': 'AS', 'MM': 'AS', 'SA': 'AS', 'MY': 'AS', 'UZ': 'AS', 'IQ': 'AS', 'AF': 'AS', 'NP': 'AS', 'YE': 'AS', 'KZ': 'AS', 'KH': 'AS', 'JO': 'AS', 'AE': 'AS', 'IL': 'AS', 'HK': 'AS', 'LA': 'AS', 'SG': 'AS', 'OM': 'AS', 'KW': 'AS', 'QA': 'AS', 'BH': 'AS', 'MN': 'AS', 'TM': 'AS', 'GE': 'AS', 'AM': 'AS', 'AZ': 'AS',
        'US': 'NA', 'CA': 'NA', 'MX': 'NA',
        'BR': 'SA', 'CO': 'SA', 'AR': 'SA', 'PE': 'SA', 'VE': 'SA', 'CL': 'SA', 'EC': 'SA', 'BO': 'SA', 'PY': 'SA', 'UY': 'SA',
        'AU': 'OC', 'NZ': 'OC', 'PG': 'OC', 'FJ': 'OC',
        'NG': 'AF', 'ET': 'AF', 'EG': 'AF', 'CD': 'AF', 'TZ': 'AF', 'ZA': 'AF', 'KE': 'AF', 'UG': 'AF', 'DZ': 'AF', 'SD': 'AF', 'MA': 'AF', 'MZ': 'AF', 'GH': 'AF', 'AO': 'AF', 'CI': 'AF', 'CM': 'AF', 'NE': 'AF', 'ML': 'AF', 'MG': 'AF', 'ZM': 'AF', 'ZW': 'AF', 'SN': 'AF', 'TN': 'AF', 'GN': 'AF', 'RW': 'AF', 'BJ': 'AF', 'SO': 'AF', 'BI': 'AF', 'TG': 'AF', 'SL': 'AF', 'LR': 'AF', 'CF': 'AF', 'CG': 'AF', 'GA': 'AF', 'GW': 'AF', 'GQ': 'AF', 'SZ': 'AF', 'LS': 'AF', 'DJ': 'AF', 'KM': 'AF', 'SC': 'AF', 'CV': 'AF',
    };

    let targetRegion = 'us-east-1'; // Default region
    const currentDomain = request.origin.custom.domainName;

    if (headers['cloudfront-viewer-country']) {
        const countryCode = headers['cloudfront-viewer-country'][0].value;
        const continent = countryToContinent[countryCode];
        if (continent && regionMapping[continent]) {
            targetRegion = regionMapping[continent];
        }
    }

    const newDomain = currentDomain.replace('us-east-1', targetRegion);

    request.origin.custom.domainName = newDomain;
    request.headers['host'] = [{ key: 'host', value: newDomain }];

    callback(null, request);
};
